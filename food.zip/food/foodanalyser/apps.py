from django.apps import AppConfig


class FoodanalyserConfig(AppConfig):
    name = 'foodanalyser'
