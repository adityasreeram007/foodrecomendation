from django.shortcuts import render
import pandas as pd
from .knn  import findnearest

def login(request):
    return render(request,'login.html')

def firstpage(request):
    if(request.method=='POST'):
        usedata=pd.read_csv('/home/aditya/Documents/food/files/userinfo.csv')
        users=list(usedata['username'])
        ages=list(usedata['age'])
        age=0
        location=''
        areadyordered=[]
        locations=list(usedata['location'])
        odered=list(usedata['already_ordered'])
        for i in range(len(users)):
            if users[i]==request.POST['uname']:
                age=ages[i]
                location=locations[i]
                alreadyordered=odered[i].split(',')
        value=findnearest(age,location)
        vallist=[]
        for k in value:
            if len(value[k])!=0:
                vallist.append(value[k])
        vallist=sum(vallist,[])
        print(vallist)


        logdata=pd.read_csv('/home/aditya/Documents/food/files/log.csv')
        u=list(logdata['usernames'])
        p=list(logdata['passwords'])
        
        for i in range(len(u)):
            if(request.POST['uname']==u[i] and request.POST['psw']==p[i]):
                return render(request,'firstpage.html',{'values':vallist})
            # else:
        return render(request,'login.html')



        
    
            
  

