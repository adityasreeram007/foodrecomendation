import pandas as pd
def findnearest(age,location):
    print(age,location)
    dictage={x:[] for x in range(1,50)}
    hasdata=pd.read_csv('/home/aditya/Documents/food/files/foodandhotels.csv')
    print(hasdata)
    ages=list(hasdata['age'])
    
    locations=list(hasdata['location'])
    
    resnames=list(hasdata['resname'])
    
    orders1=list(hasdata['ord1'])
    
    orders2=list(hasdata['ord2'])
  
    review1=list(hasdata['rev1'])
    
    review2=list(hasdata['rev2'])
    
    
    for i in range(len(ages)):
        
        diff=abs(age-i)
        print(location,locations[i])
        if locations[i]==location:
            print(location)
            if(((review1[i]+review2[i])/2)>3.00):
                dictage[diff].append({"orders":[orders1[i],orders2[i]],"restaurant names":resnames[i]})
    
    return dictage
        
print(findnearest(16,'velachery'))